import Link from "next/link";
import Image from "next/image";
import {FaWhatsapp,FaRobot,FaPlug,FaShieldAlt,FaChartLine,FaIndustry,FaStore,FaHeadset,FaCheckCircle,} from "react-icons/fa";
import {getServiceSchema} from "../lib/schema/serviceSchema";
import Script from "next/script";

export const metadata = {
  title: "WhatsApp API Service Provider | Business Messaging & Automation",
  description:
    "Mindsmiratus, a WhatsApp Business API Service provider helps businesses reach customers faster. Provide transactional and automated messages & marketing updates",
  keywords:
    "whatsapp api service provider, whatsapp business api integration, whatsapp chatbot automation, whatsapp messaging gateway, conversational marketing",
  
};

export default async function WhatsAppApiServiceProviderPage() {
  const features = [
    {
      icon: <FaWhatsapp className="text-green-600 text-3xl margin-center" />,
      title: "Official WhatsApp Business API",
      desc: "Verified templates, branded sender name, secure & compliant setup.",
    },
    {
      icon: <FaRobot className="text-green-600 text-3xl margin-center" />,
      title: "Chatbots & Automated Replies",
      desc: "Enable guided conversations to resolve routine queries instantly.",
    },
    {
      icon: <FaPlug className="text-green-600 text-3xl margin-center" />,
      title: "CRM & Application Integration",
      desc: "Connect WhatsApp with internal applications via REST APIs & webhooks.",
    },
    {
      icon: <FaChartLine className="text-green-600 text-3xl margin-center" />,
      title: "Analytics & Delivery Reporting",
      desc: "Track reads, responses, satisfaction and engagement performance.",
    },
    {
      icon: <FaShieldAlt className="text-green-600 text-3xl margin-center" />,
      title: "Secure & Compliant",
      desc: "Data encryption, audit controls and business verification assistance.",
    },
    {
      icon: <FaHeadset className="text-green-600 text-3xl margin-center" />,
      title: "Support & Onboarding",
      desc: "End-to-end setup assistance including template approvals.",
    },
  ];

  const useCases = [
    { icon: <FaStore className="text-blue-600 text-3xl margin-center" />, label: "Order & Delivery Notifications" },
    { icon: <FaIndustry className="text-blue-600 text-3xl margin-center" />, label: "Customer Support & Query Resolution" },
    { icon: <FaRobot className="text-blue-600 text-3xl margin-center" />, label: "Lead Qualification & Campaign Follow-ups" },
    { icon: <FaHeadset className="text-blue-600 text-3xl margin-center" />, label: "Post-Sale Assistance & Feedback Requests" },
  ];

  const plans = [
    {
      name: "Starter",
      volume: "Up to 5,000 Conversations / Month",
      details: [
        "Verified Sender Setup",
        "Template Approval Guidance",
        "Email Support",
      ],
    },
    {
      name: "Business",
      volume: "20,000+ Conversations / Month",
      details: [
        "Chatbot & Routing Workflows",
        "Advanced Reporting",
        "Account Manager Support",
      ],
      highlight: true,
    },
    {
      name: "Enterprise",
      volume: "Custom Scale & SLAs",
      details: [
        "High-volume Session Handling",
        "Integration Engineering Support",
        "Dedicated Success Manager",
      ],
    },
  ];

  const faqs = [
    {
      q: "What is a WhatsApp API service provider?",
      a: "A WhatsApp API service provider allows businesses to send automated messages, notifications, and campaigns using the official WhatsApp Business API. It helps companies manage customer communication at scale.",
    },
    {
      q: "Is this the official WhatsApp Business API?",
      a: "Yes. We assist in verified onboarding with WhatsApp-approved providers.",
    },
    {
      q: "Can my business use custom chatbots?",
      a: "Yes. You can configure logic-driven flows, FAQs, routing and handover to live agents.",
    },
    {
      q: "Is template approval required?",
      a: "Yes. Marketing and notification templates require approval. We assist with submission.",
    },
    {
      q: "Can I integrate this into my CRM or custom software?",
      a: "Yes. REST APIs and callback events are provided for seamless platform integration.",
    },
    {
      q: "Can I send bulk messages using the WhatsApp API?",
      a: "Yes, you can run bulk WhatsApp campaigns using pre-approved templates through the WhatsApp API. This helps businesses send promotional, transactional, and engagement messages at scale.",
    },
    {
      q: "Will I get support for green tick verification?",
      a: "Yes, we help you apply for WhatsApp Green Tick Verification (subject to platform approval).",
    },
  ];
  const serviceSchema = await getServiceSchema({
              name: "WhatsApp Business API Service Provider",
              description:
                "Official WhatsApp Business API services by Mindsmiratus Technologies to enable secure, scalable, and automated customer communication through WhatsApp messaging, notifications, chatbots, and marketing campaigns.",
              slug: "/whatsapp-api-service-provider",
              serviceType:
                "WhatsApp Business API, WhatsApp Messaging Services, WhatsApp Automation, WhatsApp Marketing, Chatbot Integration, Omnichannel Communication",

              // 🔗 Parent service relationship
              isPartOf: {
                "@type": "Service",
                name: "Customer Communication Services",
                url: "https://www.mindsmiratus.com/customer-communication-services",
              },
            });


  return (
    <>
      {/* HERO */}
      <section className="py-20 bg-gradient-to-br from-green-50 via-white to-blue-50">
        <div className="container mx-auto px-6 lg:px-16 grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 leading-tight">
              WhatsApp API Service Provider
            </h1>
            <p className="mt-5 text-lg text-slate-600">
              Grow Bigger with WhatsApp API Services of Mindsmiratus. Branded, compliant and automated WhatsApp communication for customer engagement, support and lead interaction. <strong>Connect Smarter. Engage Faster.</strong> 
            </p>
            <div className="mt-8 flex gap-4">
              <Link href="/contact-mindsmiratus-technologies" className="px-6 py-3 rounded-full bg-green-600 text-white font-semibold hover:bg-green-700">
                Request Consultation
              </Link>
            </div>
          </div>

          <div className="hidden lg:flex justify-end">
            <Image src="/whatsApp-API.png" alt="WhatsApp Business API" width={540} height={410} priority />
          </div>
        </div>
      </section>

      {/* New Section with Iframe */}
      <section className="relative py-20 bg-gradient-to-br from-blue-50 to-green-50 overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-10 left-10 w-20 h-20 bg-green-200 rounded-full"></div>
          <div className="absolute top-40 right-20 w-32 h-32 bg-blue-200 rounded-lg rotate-45"></div>
          <div className="absolute bottom-20 left-1/4 w-24 h-24 bg-yellow-200 rounded-full"></div>
        </div>
        <div className="container mx-auto px-6 lg:px-16 relative z-10">
          <iframe src='https://pinnacle.in/embedded-signup/fb-signup.php?token=hH716w0K%2B6YKxerRQ4fb1Wd3j%2FW7zXOWfOLKl5vq5wcwjmT5TpTUaJFU1qNQWB4o&app_id=cN68Ez7noCfuZ3pWtBhQ%2FA%3D%3D&config_id=sRSKeIy6BIO6BxZzW7FSaw%3D%3D&solution_id=pUtRdrSndU3whIdin7Ed8Q%3D%3D&mode=syY6PAgG1PR5fAG1p89cCw%3D%3D&themecolor=001d4c&app_secret=XAnn1UAkVRL2v%2Bzfsf3of0yoPclxOJucflOtmPlO4QybR05WC2AnJ36CK9p0MvSB' width='100%' style={{height:'80vh'}} frameBorder='0'></iframe>
        </div>
      </section>

{/* Service Overview - Improved Layout */}
<section className="bg-white">
  <div className="container mx-auto px-6 lg:px-16 grid lg:grid-cols-2 gap-12 items-center">
 {/* Image */}
    <div className="flex justify-center">
      <Image
        src="/whatsapp-message-api-service.png"   
        alt="WhatsApp Business API Workflow"
        width={420}
        height={320}
        className="w-full max-w-[420px] h-auto object-contain"
        priority
      />
    </div>
    {/* Text */}
    <div>
      <h2 className="text-3xl font-bold text-slate-900 mb-6">
        WhatsApp Business API for Professional Communication
      </h2>

      <p className="text-slate-600 leading-relaxed mb-6">
        The WhatsApp Business API enables organizations to manage customer engagement at scale. 
        It is optimized for secure, verified business communication, automated workflows, 
        and integration with internal systems and CRMs.
      </p>

      <ul className="space-y-3 text-slate-700 text-base">
        <li className="flex gap-2">
          <FaCheckCircle className="text-green-600 mt-1" />
          Official business verification & template approval support
        </li>
        <li className="flex gap-2">
          <FaCheckCircle className="text-green-600 mt-1" />
          Multi-agent dashboards and chatbot automation workflows
        </li>
        <li className="flex gap-2">
          <FaCheckCircle className="text-green-600 mt-1" />
          Secure delivery infrastructure with audit & compliance policies
        </li>
      </ul>
    </div>

   

  </div>
</section>


      {/* FEATURES */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-6 lg:px-16 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-12">Capabilities</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((f, i) => (
              <div key={i} className="p-8 bg-slate-50 rounded-2xl border border-slate-200 shadow-sm">
                {f.icon}
                <h3 className="mt-4 text-lg font-semibold text-slate-800">{f.title}</h3>
                <p className="text-slate-600 text-sm mt-2">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* USE CASES */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-6 lg:px-16">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-12">Business Use Cases</h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 text-center">
            {useCases.map((u, i) => (
              <div key={i} className="p-6 bg-white rounded-2xl border border-slate-200 shadow-sm">
                {u.icon}
                <p className="mt-3 text-slate-700 font-medium">{u.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* PRICING */}
      <section className="py-20 bg-white" id="pricing">
        <div className="container mx-auto px-6 lg:px-16 text-center">
          <h2 className="text-3xl font-bold text-slate-900 mb-12">Pricing Structure</h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {plans.map((plan, i) => (
              <div
                key={i}
                className={`p-8 rounded-2xl border shadow-lg ${
                  plan.highlight ? "border-green-600 bg-green-50" : "border-slate-200 bg-white"
                }`}
              >
                <h3 className="text-2xl font-bold text-slate-900">{plan.name}</h3>
                <p className="text-slate-600 mt-1">{plan.volume}</p>
                <ul className="mt-6 space-y-2 text-sm text-slate-700 text-left">
                  {plan.details.map((d, idx) => (
                    <li key={idx} className="flex gap-2">
                      <FaCheckCircle className="text-green-600 mt-1" /> {d}
                    </li>
                  ))}
                </ul>
                <Link
                  href="/contact-mindsmiratus-technologies"
                  className="mt-6 inline-block w-full px-6 py-3 rounded-full bg-green-600 text-white font-semibold hover:bg-green-700"
                >
                  Request Pricing
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ + CTA Split Section */}
<section className="py-20 bg-slate-50">
  <div className="container mx-auto px-6 lg:px-16">
    <div className="grid lg:grid-cols-2 gap-12 items-start">

      {/* FAQ Left */}
      <div>
        <h2 className="text-3xl font-bold text-slate-900 mb-8">Frequently Asked Questions</h2>
        <div className="space-y-4">
          {faqs.map((f, i) => (
            <details
              key={i}
              className="group border border-slate-200 rounded-2xl bg-white shadow-sm hover:shadow-md transition"
            >
              <summary className="px-6 py-4 cursor-pointer font-semibold text-slate-800 flex justify-between items-center">
                {f.q}
                <span className="text-green-600 group-open:rotate-45 transition">+</span>
              </summary>
              <div className="px-6 pb-4 text-slate-600">{f.a}</div>
            </details>
          ))}
        </div>
      </div>

      {/* CTA Right */}
       <div className="bg-gradient-to-r from-yellow-600 to-orange-500 text-white rounded-3xl p-10 shadow-xl text-center lg:text-left flex flex-col lg:flex-row items-center justify-between gap-10">

      {/* Text */}
      <div className="max-w-xl">
        <h2 className="text-3xl font-bold mb-4">
          Ready to Boost Your Brand Visibility & Lead Growth?
        </h2>
        <p className="text-lg mb-6">
          Let’s build a growth-focused digital marketing strategy customized for your business goals.
        </p>

         {/* Icons Group */}
          <div className="flex mb-9 mt-8">
            <span className="text-white text-5xl animate-bounce delay-75">📈</span>
            <span className="text-white text-5xl animate-bounce delay-150">🚀</span>
            <span className="text-white text-5xl animate-bounce delay-300">🎯</span>
          </div>

        <Link
          href="/contact-mindsmiratus-technologies"
          className="inline-flex items-center gap-2 px-6 py-3 bg-white text-yellow-700 rounded-full font-semibold hover:bg-yellow-50 transition"
        >
          Get Free Strategy Consultation
        </Link>
      </div>

     

    </div>

    </div>
  </div>
</section>
<Script
        id="structured-data-whatsapp-api-service-provider"
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify(serviceSchema),
        }}
      />
    </>
  );
}
