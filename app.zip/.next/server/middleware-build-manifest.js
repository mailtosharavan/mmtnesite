globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/1c59095c8a1ad631.js",
    "static/chunks/5cedbe3d28acc407.js",
    "static/chunks/249261e921aeebba.js",
    "static/chunks/f3e96ebafbe10e6a.js",
    "static/chunks/turbopack-80b67e51735e5d13.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];