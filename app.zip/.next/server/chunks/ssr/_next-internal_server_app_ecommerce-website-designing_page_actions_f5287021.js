module.exports=[73970,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ecommerce-website-designing_page_actions_f5287021.js.map