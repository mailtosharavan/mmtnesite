module.exports=[41049,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_mobile-app-development_page_actions_6a40dcc1.js.map