module.exports=[19082,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_voice-call-services_page_actions_3171e08e.js.map