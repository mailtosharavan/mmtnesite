module.exports=[35715,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_social-media-marketing_page_actions_cb3c6492.js.map