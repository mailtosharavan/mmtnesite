module.exports=[94098,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_google-ads-services_page_actions_a4e6e67b.js.map