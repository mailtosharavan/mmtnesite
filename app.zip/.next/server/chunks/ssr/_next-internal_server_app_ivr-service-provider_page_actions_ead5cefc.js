module.exports=[80283,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_ivr-service-provider_page_actions_ead5cefc.js.map