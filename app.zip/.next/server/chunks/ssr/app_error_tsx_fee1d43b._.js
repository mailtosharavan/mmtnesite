module.exports=[78141,a=>{"use strict";var b=a.i(87924);function c(){return(0,b.jsx)("div",{children:(0,b.jsx)("h1",{children:"Something went wrong"})})}a.s(["default",()=>c,"dynamic",0,"force-dynamic","fetchCache",0,"default-no-store","revalidate",0,0])}];

//# sourceMappingURL=app_error_tsx_fee1d43b._.js.map