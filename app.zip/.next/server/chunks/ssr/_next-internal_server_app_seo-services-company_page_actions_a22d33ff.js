module.exports=[96819,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_seo-services-company_page_actions_a22d33ff.js.map