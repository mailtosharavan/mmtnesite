module.exports=[22292,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_web-application-development_page_actions_7cdd6c8f.js.map