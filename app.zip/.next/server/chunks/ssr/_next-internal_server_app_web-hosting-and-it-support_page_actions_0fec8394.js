module.exports=[42116,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_web-hosting-and-it-support_page_actions_0fec8394.js.map