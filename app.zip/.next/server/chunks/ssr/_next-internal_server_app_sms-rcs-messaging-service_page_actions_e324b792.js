module.exports=[18294,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_sms-rcs-messaging-service_page_actions_e324b792.js.map