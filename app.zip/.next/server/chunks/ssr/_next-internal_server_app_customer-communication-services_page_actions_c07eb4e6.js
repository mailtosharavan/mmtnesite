module.exports=[78068,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_customer-communication-services_page_actions_c07eb4e6.js.map