module.exports=[35172,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_whatsapp-api-service-provider_page_actions_cf5d50f5.js.map