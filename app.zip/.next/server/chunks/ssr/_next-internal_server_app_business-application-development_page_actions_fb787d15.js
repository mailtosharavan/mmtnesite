module.exports=[12499,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_business-application-development_page_actions_fb787d15.js.map