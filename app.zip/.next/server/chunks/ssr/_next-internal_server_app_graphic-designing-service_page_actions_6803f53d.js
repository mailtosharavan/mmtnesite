module.exports=[24952,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_graphic-designing-service_page_actions_6803f53d.js.map