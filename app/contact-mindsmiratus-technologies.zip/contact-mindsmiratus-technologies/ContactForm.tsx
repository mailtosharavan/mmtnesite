"use client";

import { useEffect, useState } from "react";
import { Mail, Phone, MapPin, Send, User, MessageSquare, Shield, PhoneIcon, PhoneForwarded, Contact2 } from "lucide-react";
import { motion } from "framer-motion";
import { openGmailCompose } from "../../lib/gmail-compose";

export default function ContactForm() {
  const [formData, setFormData] = useState({ name: "", email: "", phone: "", message: "", captcha: "" });
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [captchaNumbers, setCaptchaNumbers] = useState<{ a: number; b: number } | null>(null);
  const [sendReminder, setSendReminder] = useState(false);


  useEffect(() => {
    setCaptchaNumbers({
      a: Math.floor(Math.random() * 10) + 1,
      b: Math.floor(Math.random() * 10) + 1,
    });
  }, []);

  const validate = () => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.name.trim()) newErrors.name = "Name is required.";
    if (!formData.email.trim()) newErrors.email = "Email is required.";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = "Please enter a valid email.";
    if (!formData.message.trim()) newErrors.message = "Message cannot be empty.";
    if (captchaNumbers && parseInt(formData.captcha) !== captchaNumbers.a + captchaNumbers.b)
      newErrors.captcha = "Incorrect answer. Please try again.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setErrors({ ...errors, [e.target.name]: "" });
    setSendReminder(false);
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!validate()) return;
    openGmailCompose(`Website inquiry from ${formData.name}`, [
      ["Name", formData.name],
      ["Phone", formData.phone],
      ["Email", formData.email],
      ["Message", formData.message],
    ]);
    setFormData({ name: "", email: "", phone: "", message: "", captcha: "" });
    setCaptchaNumbers({ a: Math.floor(Math.random() * 10) + 1, b: Math.floor(Math.random() * 10) + 1 });
    setSendReminder(true);
  };

  return (
    <section className="container mx-auto px-6 md:px-16 flex flex-col md:flex-row justify-between gap-12 items-start py-16">
      {/* Info Section */}
      <motion.div
        initial={{ opacity: 0, x: -30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="md:w-1/2 space-y-6"
      >
        <h2 className="text-3xl font-bold text-[#0078D7] mb-3">Let’s Connect</h2>
        <p className="text-slate-600 text-lg leading-relaxed">
          Whether it’s a new idea or a complete digital transformatio —
          <strong className="text-[#0078D7]"> Mindsmiratus Technologies Pvt. Ltd. </strong>
          is ready to bring it to life.
        </p>

        <div className="flex items-center gap-3">
          <Mail className="text-[#0078D7]" />
          <span><a href="mailto:mail@mindsmiratus.com">mail@mindsmiratus.com</a></span>
        </div>
        <div className="flex items-center gap-3">
          <Phone className="text-[#0078D7]" />
          <span><a href="tel:+919625306474">+91-9625306474</a></span>
        </div>
        <div className="flex items-center gap-3">
          <Contact2 className="text-[#0078D7]" />
          <span><a href="tel:+01144786201">+011 44786201</a></span>
        </div>
        <div className="flex items-center gap-3">
          <MapPin className="text-[#0078D7]" />
          <span>A-263, 1st Floor, Vishwakarma Colony, Delhi 110044, India</span>
        </div>
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3373.864727617972!2d77.28450047522125!3d28.501740890008495!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce3f8f4aa824f%3A0x11711854f86aeab0!2sMindsmiratus%20Technologies%20Pvt%20Ltd!5e1!3m2!1sen!2sin!4v1766750856552!5m2!1sen!2sin" width="100%" height="215px" loading="lazy" ></iframe>
      </motion.div>

      {/* Contact Form */}
      <motion.form
        onSubmit={handleSubmit}
        initial={{ opacity: 0, x: 30 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="md:w-1/2 relative bg-white p-10 rounded-2xl shadow-2xl border border-slate-100 overflow-hidden"
      >
        <div className="absolute inset-0 bg-gradient-to-br from-[#EAF3FF] via-white to-transparent opacity-70 pointer-events-none rounded-2xl" />

        <div className="relative z-10 space-y-6">
            {sendReminder && <p role="status" className="rounded-lg bg-blue-50 p-3 text-center text-sm font-semibold text-[#005fb0]">Your email draft is ready. Please review it and press Send from your email account to submit your inquiry.</p>}
            {/* Name Field */}
            <div className="relative">
              <User className="absolute left-3 top-4 text-[#0078D7]" />
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className={`peer w-full pl-10 border-b-2 bg-transparent py-3 text-slate-800 focus:outline-none focus:border-[#0078D7] ${errors.name ? "border-red-500" : "border-slate-300"
                  }`}
              />
              <label
                className={`absolute left-10 top-3 text-slate-500 bg-white px-1 transition-all duration-200 ${formData.name
                  ? "top-[-10px] text-sm text-[#0078D7]"
                  : "peer-placeholder-shown:top-3 peer-placeholder-shown:text-base"
                  } peer-focus:top-[-10px] peer-focus:text-sm peer-focus:text-[#0078D7]`}
              >
                Your Name
              </label>
              {errors.name && <p className="text-sm text-red-500 mt-1">{errors.name}</p>}
            </div>
            {/* Phone Field */}
            <div className="relative">
              <Phone className="absolute left-3 top-4 text-[#0078D7]" />
              <input type="tel" name="phone" value={formData.phone} onChange={handleChange}
                className={`peer w-full pl-10 border-b-2 bg-transparent py-3 text-slate-800 focus:outline-none focus:border-[#0078D7] ${errors.phone ? "border-red-500" : "border-slate-300"
                  }`}
              />
              <label
                className={`absolute left-10 top-3 text-slate-500 bg-white px-1 transition-all duration-200 ${formData.phone
                  ? "top-[-10px] text-sm text-[#0078D7]"
                  : "peer-placeholder-shown:top-3 peer-placeholder-shown:text-base"
                  } peer-focus:top-[-10px] peer-focus:text-sm peer-focus:text-[#0078D7]`}
              >
                Phone Number
              </label>
              {errors.phone && <p className="text-sm text-red-500 mt-1">{errors.phone}</p>}
            </div>

            {/* Email Field */}
            <div className="relative">
              <Mail className="absolute left-3 top-4 text-[#0078D7]" />
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                className={`peer w-full pl-10 border-b-2 bg-transparent py-3 text-slate-800 focus:outline-none focus:border-[#0078D7] ${errors.email ? "border-red-500" : "border-slate-300"
                  }`}
              />
              <label
                className={`absolute left-10 top-3 text-slate-500 bg-white px-1 transition-all duration-200 ${formData.email
                  ? "top-[-10px] text-sm text-[#0078D7]"
                  : "peer-placeholder-shown:top-3 peer-placeholder-shown:text-base"
                  } peer-focus:top-[-10px] peer-focus:text-sm peer-focus:text-[#0078D7]`}
              >
                Email Address
              </label>
              {errors.email && <p className="text-sm text-red-500 mt-1">{errors.email}</p>}
            </div>

            {/* Message Field */}
            <div className="relative">
              <MessageSquare className="absolute left-3 top-4 text-[#0078D7]" />
              <textarea
                name="message"
                rows={4}
                value={formData.message}
                onChange={handleChange}
                className={`peer w-full pl-10 border-b-2 bg-transparent py-3 text-slate-800 focus:outline-none focus:border-[#0078D7] ${errors.message ? "border-red-500" : "border-slate-300"
                  }`}
              ></textarea>
              <label
                className={`absolute left-10 top-3 text-slate-500 bg-white px-1 transition-all duration-200 ${formData.message
                  ? "top-[-10px] text-sm text-[#0078D7]"
                  : "peer-placeholder-shown:top-3 peer-placeholder-shown:text-base"
                  } peer-focus:top-[-10px] peer-focus:text-sm peer-focus:text-[#0078D7]`}
              >
                Your Message
              </label>
              {errors.message && <p className="text-sm text-red-500 mt-1">{errors.message}</p>}
            </div>

            {/* Anti-Robot Field */}
            <div className="relative">
              <Shield className="absolute left-3 top-4 text-[#0078D7]" />
              <input
                type="text"
                name="captcha"
                value={formData.captcha}
                onChange={handleChange}
                placeholder={
                  captchaNumbers ? `What is ${captchaNumbers.a} + ${captchaNumbers.b}?` : "Loading..."
                }
                className={`peer w-full pl-10 border-b-2 bg-transparent py-3 text-slate-800 focus:outline-none focus:border-[#0078D7] ${errors.captcha ? "border-red-500" : "border-slate-300"
                  }`}
              />
              {errors.captcha && <p className="text-sm text-red-500 mt-1">{errors.captcha}</p>}
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="flex items-center justify-center gap-2 w-full bg-[#0078D7] text-white py-3 rounded-full mt-4 transition-all duration-300 shadow-md hover:shadow-lg hover:bg-[#005fb0]"
            >
              <Send className="w-5 h-5" /> Send Message
            </button>

        </div>
      </motion.form>
    </section>
  );
}
